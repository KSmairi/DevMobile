package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.database.*;
import android.database.sqlite.*;
import android.content.Intent;
import android.widget.Button;
import android.os.Bundle;
import android.view.View;

import java.sql.*;


public class MainActivity extends AppCompatActivity {
    static SQLiteDatabase dataBase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dataBase = openOrCreateDatabase("Client",MODE_PRIVATE,null);
        dataBase.execSQL("CREATE TABLE if not EXISTS client( id INTEGER not NULL PRIMARY KEY AUTOINCREMENT , nom char(45) NOT NULL, adresse char (250) NOT NULL, telephone INTEGER NOT NULL, fax INTEGER , contact char(45), adresseContact char(200) );");
        dataBase.execSQL("CREATE TABLE if not EXISTS contrat( idC INTEGER not NULL PRIMARY KEY AUTOINCREMENT , reference char(45) NOT NULL, dateDebut DATE NOT NULL, dateFin DATE NOT NULL, id INTEGER not NULL, redevence DECIMAL Not NULL, FOREIGN KEY (id) REFERENCES client(id) );");


        Button button1;
        button1 = (Button) findViewById(R.id.ToGestionContrat);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity();
            }
        });
        Button button2;
        button2 = (Button) findViewById(R.id.ToGestionClient);
        button2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openNewActivity2();
            }
        });

        Button button3;
        button3 = (Button) findViewById(R.id.ToAjouterClient);
        button3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openNewActivity3();
            }
        });

    }
    public void openNewActivity(){
        Intent intent = new Intent(this, GestionContrat.class);
        startActivity(intent);
    }
    public void openNewActivity2(){
        Intent intent = new Intent(this, GestionClient.class);
        startActivity(intent);
    }
    public void openNewActivity3(){
        Intent intent = new Intent(this, AddClient.class);
        startActivity(intent);
    }

    public static void AddClient(String Name,String Address,int Phone,int Fax,String Contact,String ContactAddress){
        dataBase.execSQL("insert into client (nom,adresse,telephone,fax,contact,adressecontact) VALUES ('"+Name+"','"+Address+"',"+Phone+","+Fax+",'"+Contact+"','"+ContactAddress+"');");
    }

    public static void AddContrat(String Reference, Date startDate, Date endDate, int idClient, float redevence){
        dataBase.execSQL("INSERT INTO contrat(reference,datedebut,datefin,id,redevence) values ('"+Reference+"','"+startDate+"','"+endDate+"',"+idClient+",'"+redevence+"');");
    }

    public static void DeleteClient(String Name){
        dataBase.execSQL("DELETE FROM client WHERE nom = '"+Name+"';");
    }
    public static void DeleteContrat(String reference){
        dataBase.execSQL("DELETE FROM contrat WHERE reference = '"+reference+"';");
    }

    public static void UpdateTableInClient(String TableReference,String address,int phone,int Fax,String contact,String contactadresse){
        dataBase.execSQL("UPDATE client Set adresse='"+address+"',telephone="+phone+",fax="+Fax+",contact='"+contact+"',contactadresse='"+contactadresse+"' where nom='"+TableReference+"';");
    }

    public static void UpdateTableInContrat(String TableReference,Date datedebut,Date datefin,int id,float redevence){
        dataBase.execSQL("UPDATE contrat SET datedebut='"+datedebut+"',datefin='"+datefin+"',id="+id+",redevence="+redevence+" where reference='"+TableReference+"';");
    }

    public static Cursor SearchClient(String Name){
        String Query = "SELECT * FROM client where nom='?'";
        String[] Argument ={Name};
        Cursor cursor = dataBase.rawQuery(Query,Argument);
        return cursor;
    }
    public static Cursor SearchContrat(String reference){
        String Query = "SELECT * FROM contrat where reference='?'";
        String[] Argument ={reference};
        Cursor cursor = dataBase.rawQuery(Query,Argument);
        return cursor;
    }
}